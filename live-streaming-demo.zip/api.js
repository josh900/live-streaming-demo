export default {
    key: "YWRtaW4xQHNrb29wLmRpZ2l0YWw:quCILV7kl0vt4FJEvJLvf",
    url: "https://api.d-id.com",
    service: "talks",
    groqKey: "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",
    deepgramKey: "ab184815a3899aea7e3add69b9d5b7bc6894dc74"
};